-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : flow_background
-- 
-- Part : #1
-- Date : 2017-03-14 15:42:11
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `flow_admin`
-- -----------------------------
DROP TABLE IF EXISTS `flow_admin`;
CREATE TABLE `flow_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `password` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '密码',
  `loginnum` int(11) DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '真实姓名',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  `groupid` int(11) DEFAULT '1' COMMENT '用户角色id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `flow_admin`
-- -----------------------------
INSERT INTO `flow_admin` VALUES ('1', 'admin', '218dbb225911693af03a713581a7227f', '224', '127.0.0.1', '1489471298', 'admin', '1', '1');
INSERT INTO `flow_admin` VALUES ('3', 'test', '218dbb225911693af03a713581a7227f', '0', '', '0', '秦林慧', '1', '8');

-- -----------------------------
-- Table structure for `flow_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `flow_auth_group`;
CREATE TABLE `flow_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` char(255) NOT NULL DEFAULT '',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `flow_auth_group`
-- -----------------------------
INSERT INTO `flow_auth_group` VALUES ('1', '超级管理员', '1', '', '1446535750', '1446535750');
INSERT INTO `flow_auth_group` VALUES ('8', '访客', '1', '1,2,67,3,68,4,107,73,5,6,7,13,14,24,79,88,92,54,59,84,26,27,83,32,33,34,36,80,37,94,98,96,100,95,101,102,103,105,38,63,64,87,39,65,106', '1484203483', '1489476983');

-- -----------------------------
-- Table structure for `flow_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `flow_auth_group_access`;
CREATE TABLE `flow_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `flow_auth_group_access`
-- -----------------------------
INSERT INTO `flow_auth_group_access` VALUES ('1', '1');

-- -----------------------------
-- Table structure for `flow_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `flow_auth_rule`;
CREATE TABLE `flow_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `flow_auth_rule`
-- -----------------------------
INSERT INTO `flow_auth_rule` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '7', '1446535750', '1484296512');
INSERT INTO `flow_auth_rule` VALUES ('2', 'admin/user/index', '用户管理', '1', '1', 'fa-arrow', '', '1', '0', '1446535750', '1484618580');
INSERT INTO `flow_auth_rule` VALUES ('3', 'admin/role/index', '角色管理', '1', '1', '', '', '1', '0', '1446535750', '0');
INSERT INTO `flow_auth_rule` VALUES ('4', 'admin/menu/index', '菜单管理', '1', '1', '', '', '1', '0', '1446535750', '0');
INSERT INTO `flow_auth_rule` VALUES ('5', '#', '数据库管理', '1', '1', 'fa fa-database', '', '0', '6', '1446535750', '0');
INSERT INTO `flow_auth_rule` VALUES ('6', 'admin/data/index', '数据备份', '1', '1', '', '', '5', '0', '1446535750', '1484209857');
INSERT INTO `flow_auth_rule` VALUES ('7', 'admin/data/importdata', '备份数据', '1', '1', '', '', '6', '0', '0', '0');
INSERT INTO `flow_auth_rule` VALUES ('8', 'admin/data/backdata', '还原数据', '1', '1', '', '', '6', '0', '0', '0');
INSERT INTO `flow_auth_rule` VALUES ('9', 'admin/user/useradd', '添加用户', '1', '1', '', '', '2', '10', '0', '0');
INSERT INTO `flow_auth_rule` VALUES ('10', 'admin/user/useredit', '编辑用户', '1', '1', '', '', '2', '10', '0', '0');
INSERT INTO `flow_auth_rule` VALUES ('11', 'admin/user/userdel', '删除用户', '1', '1', '', '', '2', '10', '0', '0');
INSERT INTO `flow_auth_rule` VALUES ('12', 'admin/user/user_state', '用户状态更改', '1', '1', '', '', '2', '10', '0', '0');
INSERT INTO `flow_auth_rule` VALUES ('13', '#', '日志管理', '1', '1', 'fa fa-tasks', '', '0', '5', '0', '0');
INSERT INTO `flow_auth_rule` VALUES ('14', 'admin/log/operate_log', '操作日志', '1', '1', '', '', '13', '0', '0', '0');
INSERT INTO `flow_auth_rule` VALUES ('24', '#', '广告管理', '1', '1', 'fa fa-image', '', '0', '4', '1484105652', '1484204130');
INSERT INTO `flow_auth_rule` VALUES ('79', 'admin/ad/index', '广告列表', '1', '1', '', '', '24', '0', '1484299236', '1484299236');
INSERT INTO `flow_auth_rule` VALUES ('26', '#', '文章管理', '1', '1', 'fa fa-paste', '', '0', '0', '1484203163', '1484203163');
INSERT INTO `flow_auth_rule` VALUES ('27', 'admin/article/index_cate', '文章分类', '1', '1', '', '', '26', '0', '1484203256', '1484203256');
INSERT INTO `flow_auth_rule` VALUES ('28', 'admin/article/add_cate', '添加分类', '1', '1', '', '', '27', '0', '1484203362', '1484618240');
INSERT INTO `flow_auth_rule` VALUES ('29', 'admin/article/edit_cate', '编辑分类', '1', '1', '', '', '27', '0', '1484203381', '1484203381');
INSERT INTO `flow_auth_rule` VALUES ('30', 'admin/article/del_cate', '删除分类', '1', '1', '', '', '27', '0', '1484203404', '1484203404');
INSERT INTO `flow_auth_rule` VALUES ('31', 'admin/article/cate_state', '分类状态', '1', '1', '', '', '27', '0', '1484203439', '1484203439');
INSERT INTO `flow_auth_rule` VALUES ('32', 'admin/article/index', '文章列表', '1', '1', '', '', '26', '0', '1484204579', '1484204579');
INSERT INTO `flow_auth_rule` VALUES ('33', 'admin/article/add_article', '添加文章', '1', '1', '', '', '32', '0', '1484204697', '1484204697');
INSERT INTO `flow_auth_rule` VALUES ('34', 'admin/article/edit_article', '编辑文章', '1', '1', '', '', '32', '0', '1484204723', '1484204723');
INSERT INTO `flow_auth_rule` VALUES ('35', 'admin/article/del_article', '删除文章', '1', '1', '', '', '32', '0', '1484204742', '1484204742');
INSERT INTO `flow_auth_rule` VALUES ('36', 'admin/article/article_state', '文章状态', '1', '1', '', '', '32', '0', '1484204768', '1484204768');
INSERT INTO `flow_auth_rule` VALUES ('37', '#', '会员管理', '1', '1', 'fa fa-user', '', '0', '1', '1484205988', '1484205988');
INSERT INTO `flow_auth_rule` VALUES ('38', '#', '留言管理', '1', '1', 'fa fa-pencil', '', '0', '3', '1484206505', '1484206505');
INSERT INTO `flow_auth_rule` VALUES ('39', '#', '订单管理', '1', '1', 'fa fa-money', '', '0', '2', '1484206629', '1484206629');
INSERT INTO `flow_auth_rule` VALUES ('40', 'admin/data/import', '数据库还原', '1', '1', '', '', '5', '0', '1484209681', '1484209757');
INSERT INTO `flow_auth_rule` VALUES ('41', 'admin/data/revert', '还原', '1', '1', '', '', '40', '0', '1484209786', '1484209786');
INSERT INTO `flow_auth_rule` VALUES ('42', 'admin/data/del', '删除', '1', '1', '', '', '40', '0', '1484209807', '1484209807');
INSERT INTO `flow_auth_rule` VALUES ('98', 'admin/member/edit_leval', '编辑等级', '1', '1', '', '', '94', '0', '1484618631', '1484618631');
INSERT INTO `flow_auth_rule` VALUES ('94', 'admin/member/index_leval', '等级列表', '1', '1', '', '', '37', '0', '1484618316', '1484618316');
INSERT INTO `flow_auth_rule` VALUES ('95', 'admin/member/index', '会员列表', '1', '1', '', '', '37', '0', '1484618334', '1484618400');
INSERT INTO `flow_auth_rule` VALUES ('96', 'admin/member/index_leval', '会员等级列表', '1', '1', '', '', '94', '0', '1484618452', '1484618452');
INSERT INTO `flow_auth_rule` VALUES ('97', 'admin/member/add_leval', '添加等级', '1', '1', '', '', '94', '0', '1484618610', '1484618610');
INSERT INTO `flow_auth_rule` VALUES ('54', 'admin/ad/index_position', '广告位', '1', '1', '', '', '24', '0', '1484295129', '1486562268');
INSERT INTO `flow_auth_rule` VALUES ('107', 'admin/ajax/getMenuList', '获取菜单列表权限', '1', '1', '', '', '4', '0', '1486630504', '1486630653');
INSERT INTO `flow_auth_rule` VALUES ('99', 'admin/member/del_leval', '删除等级', '1', '1', '', '', '94', '0', '1484618648', '1484618648');
INSERT INTO `flow_auth_rule` VALUES ('100', 'admin/member/state_leval', '等级状态', '1', '1', '', '', '94', '0', '1484618676', '1484618676');
INSERT INTO `flow_auth_rule` VALUES ('59', 'admin/ad/add_position', '添加广告位', '1', '1', '', '', '54', '0', '1484295332', '1486563972');
INSERT INTO `flow_auth_rule` VALUES ('60', 'admin/ad/edit_advposition', '编辑广告位', '1', '1', '', '', '54', '0', '1484295352', '1484295709');
INSERT INTO `flow_auth_rule` VALUES ('61', 'admin/ad/del_advposition', '删除广告位', '1', '1', '', '', '54', '0', '1484295368', '1484295723');
INSERT INTO `flow_auth_rule` VALUES ('62', 'admin/ad/change_advposition_status', '广告位状态', '1', '1', '', '', '54', '0', '1484295669', '1484295669');
INSERT INTO `flow_auth_rule` VALUES ('63', 'admin/leave/index', '留言列表', '1', '1', '', '', '38', '0', '1484295882', '1484295882');
INSERT INTO `flow_auth_rule` VALUES ('64', 'admin/leave/del_message', '删除留言', '1', '1', '', '', '63', '0', '1484295956', '1484295956');
INSERT INTO `flow_auth_rule` VALUES ('65', 'admin/order/index', '订单列表', '1', '1', '', '', '39', '0', '1484296010', '1484296010');
INSERT INTO `flow_auth_rule` VALUES ('66', 'admin/order/del_order', '删除订单', '1', '1', '', '', '65', '0', '1484296035', '1484296035');
INSERT INTO `flow_auth_rule` VALUES ('67', 'admin/user/index', '用户列表', '1', '1', '', '', '2', '0', '1484298351', '1484298351');
INSERT INTO `flow_auth_rule` VALUES ('68', 'admin/role/index', '角色列表', '1', '1', '', '', '3', '0', '1484298440', '1484298461');
INSERT INTO `flow_auth_rule` VALUES ('69', 'admin/role/roleAdd', '添加角色', '1', '1', '', '', '3', '0', '1484298559', '1484298559');
INSERT INTO `flow_auth_rule` VALUES ('70', 'admin/role/roleEdit', '编辑角色', '1', '1', '', '', '3', '0', '1484298587', '1484298587');
INSERT INTO `flow_auth_rule` VALUES ('71', 'admin/role/roleDel', '删除角色', '1', '1', '', '', '3', '0', '1484298633', '1484298633');
INSERT INTO `flow_auth_rule` VALUES ('72', 'admin/role/role_state', '角色状态', '1', '1', '', '', '3', '0', '1484298687', '1484298687');
INSERT INTO `flow_auth_rule` VALUES ('73', 'admin/menu/index', '菜单列表', '1', '1', '', '', '4', '0', '1484298835', '1484298835');
INSERT INTO `flow_auth_rule` VALUES ('74', 'admin/menu/add_rule', '添加菜单', '1', '1', '', '', '4', '0', '1484298973', '1484298973');
INSERT INTO `flow_auth_rule` VALUES ('75', 'admin/menu/edit_rule', '编辑菜单', '1', '1', '', '', '4', '0', '1484299013', '1484299013');
INSERT INTO `flow_auth_rule` VALUES ('76', 'admin/menu/del_rule', '删除菜单', '1', '1', '', '', '4', '0', '1484299031', '1484299031');
INSERT INTO `flow_auth_rule` VALUES ('77', 'admin/menu/rule_state', '菜单状态', '1', '1', '', '', '4', '0', '1484299061', '1484299061');
INSERT INTO `flow_auth_rule` VALUES ('82', 'admin/menu/ruleorder', '菜单排序', '1', '1', '', '', '4', '0', '1484299382', '1484299382');
INSERT INTO `flow_auth_rule` VALUES ('80', 'admin/article/index', '文章列表', '1', '1', '', '', '32', '0', '1484299303', '1484299303');
INSERT INTO `flow_auth_rule` VALUES ('106', 'admin/order/index', '订单列表', '1', '1', '', '', '65', '0', '1486627868', '1486627868');
INSERT INTO `flow_auth_rule` VALUES ('83', 'admin/article/index_cate', '分类列表', '1', '1', '', '', '27', '0', '1484299497', '1484299497');
INSERT INTO `flow_auth_rule` VALUES ('84', 'admin/adv/index_position', '广告位列表', '1', '1', '', '', '54', '0', '1484299537', '1486547232');
INSERT INTO `flow_auth_rule` VALUES ('87', 'admin/leave/index', '留言列表', '1', '1', '', '', '63', '0', '1484299798', '1484299798');
INSERT INTO `flow_auth_rule` VALUES ('88', 'admin/ad/index', '广告列表', '1', '1', '', '', '79', '0', '1484300214', '1484300214');
INSERT INTO `flow_auth_rule` VALUES ('89', 'admin/ad/add_ad', '添加广告', '1', '1', '', '', '79', '0', '1484300281', '1484300281');
INSERT INTO `flow_auth_rule` VALUES ('90', 'admin/ad/edit_ad', '编辑广告', '1', '1', '', '', '79', '0', '1484300309', '1484300309');
INSERT INTO `flow_auth_rule` VALUES ('91', 'admin/ad/del_ad', '删除广告', '1', '1', '', '', '79', '50', '1484300337', '1484300337');
INSERT INTO `flow_auth_rule` VALUES ('92', 'admin/ad/ad_state', '广告状态', '1', '1', '', '', '79', '0', '1484300361', '1484300361');
INSERT INTO `flow_auth_rule` VALUES ('101', 'admin/member/index', '会员列表', '1', '1', '', '', '95', '0', '1484618711', '1484618711');
INSERT INTO `flow_auth_rule` VALUES ('102', 'admin/member/add_user', '添加会员', '1', '1', '', '', '95', '0', '1484618730', '1484618730');
INSERT INTO `flow_auth_rule` VALUES ('103', 'admin/member/edit_user', '编辑会员', '1', '1', '', '', '95', '0', '1484618760', '1484618760');
INSERT INTO `flow_auth_rule` VALUES ('104', 'admin/member/del_user', '删除会员', '1', '1', '', '', '95', '0', '1484618784', '1484618784');
INSERT INTO `flow_auth_rule` VALUES ('105', 'admin/member/member_state', '会员状态', '1', '1', '', '', '95', '0', '1484618815', '1484618815');
INSERT INTO `flow_auth_rule` VALUES ('108', 'admin/user/ceshi', '测试菜单', '1', '0', 'fa fa-user', '', '0', '0', '1489472395', '1489472395');

-- -----------------------------
-- Table structure for `flow_log`
-- -----------------------------
DROP TABLE IF EXISTS `flow_log`;
CREATE TABLE `flow_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=530 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `flow_log`
-- -----------------------------
INSERT INTO `flow_log` VALUES ('515', '1', 'admin', '用户【admin】登录失败：密码错误', '127.0.0.1', '2', '1489461381');
INSERT INTO `flow_log` VALUES ('516', '1', '', '用户【】登录成功', '127.0.0.1', '1', '1489461989');
INSERT INTO `flow_log` VALUES ('517', '1', '', '用户【】登录成功', '127.0.0.1', '1', '1489463458');
INSERT INTO `flow_log` VALUES ('518', '1', '', '用户【】登录成功', '127.0.0.1', '1', '1489467917');
INSERT INTO `flow_log` VALUES ('519', '1', '', '用户【】登录成功', '127.0.0.1', '1', '1489470319');
INSERT INTO `flow_log` VALUES ('520', '1', '', '用户【】登录成功', '127.0.0.1', '1', '1489470393');
INSERT INTO `flow_log` VALUES ('521', '1', '', '用户【】登录成功', '127.0.0.1', '1', '1489471298');
INSERT INTO `flow_log` VALUES ('522', '1', 'admin', '用户【admin】添加菜单成功', '127.0.0.1', '1', '1489472395');
INSERT INTO `flow_log` VALUES ('523', '1', 'admin', '用户【test】添加成功', '127.0.0.1', '1', '1489473210');
INSERT INTO `flow_log` VALUES ('524', '1', 'admin', '用户【test】添加成功', '127.0.0.1', '1', '1489475981');
INSERT INTO `flow_log` VALUES ('525', '1', 'admin', '用户【111】添加成功', '127.0.0.1', '1', '1489476869');
INSERT INTO `flow_log` VALUES ('526', '1', 'admin', '用户【test1】编辑成功', '127.0.0.1', '1', '1489476911');
INSERT INTO `flow_log` VALUES ('527', '1', 'admin', '用户【test】编辑成功', '127.0.0.1', '1', '1489477012');
INSERT INTO `flow_log` VALUES ('528', '1', '', '用户【admin】删除管理员成功(ID=4)', '127.0.0.1', '1', '1489477026');
INSERT INTO `flow_log` VALUES ('529', '1', '', '用户【admin】删除管理员成功(ID=5)', '127.0.0.1', '1', '1489477033');
